﻿namespace NorthwindManager.Dtos
{
  public class EmployeeDto
  {
    public long Id { get; set; }
    public string Name { get; set; }
    public string City { get; set; }
    public string Country { get; set; }
  }
}
